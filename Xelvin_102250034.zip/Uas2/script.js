function show(page) {
  const p = (page || '').toLowerCase().trim();
  const pageEl = document.getElementById('page-' + p);
  const navEl = document.getElementById('nav-' + p);

  // Jika page tidak ada, fallback ke bio
  if (!pageEl) {
    const bioEl = document.getElementById('page-bio');
    const bioNav = document.getElementById('nav-bio');
    document.querySelectorAll('.page').forEach(el => el.classList.remove('active'));
    document.querySelectorAll('.nav-links a').forEach(el => el.classList.remove('active'));
    bioEl?.classList.add('active');
    bioNav?.classList.add('active');
    return;
  }

  document.querySelectorAll('.page').forEach(el => el.classList.remove('active'));
  document.querySelectorAll('.nav-links a').forEach(el => el.classList.remove('active'));

  pageEl.classList.add('active');
  navEl?.classList.add('active');
}

function pageFromHash() {
  const hash = (window.location.hash || '').replace('#', '').trim().toLowerCase();
  if (!hash) return 'bio';
  return hash;
}

document.addEventListener('DOMContentLoaded', function () {
  show(pageFromHash());
});

window.addEventListener('hashchange', function () {
  show(pageFromHash());
});
